require("./system/module.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "6283120589335"
global.namabot = "Destructive" 
global.namaowner = "Aʟ͢ᴘ͋ɪɴ Dᴇᴠᴇ͢ʟᴏ͋ᴠᴇʀ͚"
global.linkgc = '-'
global.linksaluran = "https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s"
global.fotomenu = "https://img5.pixhost.to/images/2976/568719328_alpindev.jpg"
global.packname = "Aʟ͢ᴘ͋ɪɴ Dᴇᴠᴇ͢ʟᴏ͋ᴠᴇʀ͚"
global.author = "Aʟ͢ᴘ͋ɪɴ Dᴇᴠᴇ͢ʟᴏ͋ᴠᴇʀ͚"


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "120363373139271790@newsletter"
global.namasaluran = "ЅаlцѓаиДlріиҀѓаѕheѓↁevelорeѓ͚"
global.idSaluran = "120363373139271790@newsletter"

global.image = "https://img5.pixhost.to/images/2976/568719328_alpindev.jpg"

// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "Belum Tersedia"
global.ovo = "Belum tersedia"
global.gopay = "Belum tersedia"
global.qris = "https://img5.pixhost.to/images/2976/568719328_alpindev.jpg"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://-"
global.apikey = "-" // Isi api ptla
global.capikey = "-" // Isi api ptlc


// >~~~~~~~~ Setting Message ~~~~~~~~~< //
global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin",
succes: " Sukses menjadikan nya sebagai owner"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})