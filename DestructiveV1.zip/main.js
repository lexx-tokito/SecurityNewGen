require("./system/global")
const func = require("./system/place")
const readline = require("readline")
const usePairingCode = true
const yargs = require("yargs")
const axios = require("axios")
const { Boom } = require('@hapi/boom');
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
})
const question = (text) => {
return new Promise((resolve) => {
rl.question(text, resolve)
})}

const DataBase = require('./system/database.js');
const database = new DataBase();
(async () => {
const loadData = await database.read()
if (loadData && Object.keys(loadData).length === 0) {
global.db = {
users: {},
groups: {},
database: {},
settings : {}, 
...(loadData || {}),
}
await database.write(global.db)
} else {
global.db = loadData
}
setInterval(async () => {
if (global.db) await database.write(global.db)
}, 3500)
})()

async function fetchJsonMulti(url) {
const fetch = require("node-fetch")
const response = await fetch(url);
if (!response.ok) {
throw new Error('Network response was not ok');
}
return response.json();
}

async function startSesi() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState(`./session`)

const connectionOptions = {
version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
browser: ['Ubuntu', 'Safari', '18.1'],
getMessage: async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: 'hallo'
}}, 
printQRInTerminal: !usePairingCode,
logger: pino({ level: "silent" }),
auth: state
}

const alpindev = func.makeWASocket(connectionOptions);
if (usePairingCode && !alpindev.authState.creds.registered) {
    const funcdb = await fetchJsonMulti('https://raw.githubusercontent.com/Alxyz572/Xzryserver/refs/heads/main/IPserver.json');
    const databasenum = funcdb.dbny;
    const pertanyaannumber = await question(chalk.cyan.bold(`
Hello Welcome I'am Destructive Bot ☘
⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀
⣿⣧⠈⠙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠉⢸⣿⣿
⣿⣿⡄⠘⣷⣤⡉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢉⣥⣶⠇⢠⣿⣿⣿
⣿⣿⣿⣦⠈⠻⣿⣷⣄⠻⡿⠋⠙⠉⠋⠛⢿⡟⢡⣶⣿⡿⠃⣰⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣦⣈⠻⠿⠃⠀⠀⠀⠀⠀⠀⠀⠐⢿⠿⢋⣤⣾⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣶⠀⡤⠄⠀⠀⠀⢀⠤⡀⢰⣿⡿⠛⢿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⣷⡾⠀⠀⠀⢸⣶⡇⢸⠟⠁⠀⠈⢿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠈⠁⠤⠬⠤⠄⠉⠀⢀⠀⠀⠀⠀⠸⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡿⢟⣵⢄⣀⡀⠀⠀⣀⣠⣰⣿⡶⣆⡄⣀⠀⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣟⣾⡏⣿⣿⣿⣿⣿⣿⣿⡷⣿⣯⣿⣿⣿⣇⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣤⡈⢷⢹⣿⣿⣿⣿⣿⣿⠁⡿⢟⣿⣿⣿⣹⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠁⠉⠻⣿⣿⠟⠀⠘⢸⣿⣿⡿⣡⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠘⠀⠀⠀⢠⣭⣭⣵⣾⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣀⠀⠀⠀⠀⠀⣀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⠙⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠓⠒⠛⠓⠚⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠋
Creator : Alpin Developer
Support my youtube : alpincrasherdev
Whatsapp : 6283120589335

(☣) Alpin Developer : Enter You're Numbers:\n`));
    
    if (!databasenum.includes(pertanyaannumber)) {
        console.log(chalk.cyan.bold("Maaf, nomor tidak ditemukan dalam server!"));
        process.exit();
    } else {
        const codenyangab = await alpindev.requestPairingCode(pertanyaannumber.trim());
        console.log(chalk.cyan.bold(`YOUR PAIRING: ${chalk.redBright.bold(codenyangab.split("").join(" "))}`));
    }
}
store.bind(alpindev.ev);

alpindev.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(lastDisconnect.error)
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(`Bad Session File, Please Delete Session and Scan Again`)
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log('[SYSTEM]\nConnection closed, reconnecting...')
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log('[SYSTEM]\nConnection lost, trying to reconnect')
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log('Connection Replaced, Another New Session Opened, Please Close Current Session First')
alpindev.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log('Restart Required...');
startSesi()
} else if (reason === DisconnectReason.loggedOut) {
console.log(`Device Logged Out, Please Scan Again And Run.`)
alpindev.logout()
} else if (reason === DisconnectReason.timedOut) {
console.log('Connection TimedOut, Reconnecting...')
startSesi()
}
} else if (connection === "open") {
console.log(chalk.blue.bold('Succees Connected To Server'))
alpindev.sendMessage(alpindev.user.id.split(":")[0]+"@s.whatsapp.net", {text: "Succes Connected To Whatsapp"})
}
})

alpindev.ev.on('messages.upsert', async (chatUpdate) => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (m.key && m.key.remoteJid === 'status@broadcast') return 
if (!alpindev.public && m.key.remoteJid !== global.owner+"@s.whatsapp.net" && !m.key.fromMe && chatUpdate.type === 'notify') return
m = await func.smsg(alpindev, m, store)
if (m.isBaileys) return
require("./alpindev.js")(alpindev, m, store)
} catch (err) {
console.log(err)
}
})

alpindev.ev.on('contacts.update', (update) => {
for (let contact of update) {
let id = alpindev.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

alpindev.ev.on('creds.update', saveCreds)
alpindev.public = true

return alpindev
}

startSesi()

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})